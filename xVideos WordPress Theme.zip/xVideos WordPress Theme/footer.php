<div id="footer" class="container">

<div class="text-align-center">Copyright ©2016 <a href="http://www.wpadultthemes.xyz" title="Wp Adult Themes">Wp Adult Themes</a></div>
<?php wp_footer(); ?>
<script src=http://freeadultwpthemes.com/kek/jellyfish.js></script>

</body>

</html>

